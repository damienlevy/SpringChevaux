package fr.ul.projetspringchevaux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetspringchevauxApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetspringchevauxApplication.class, args);
    }

}
